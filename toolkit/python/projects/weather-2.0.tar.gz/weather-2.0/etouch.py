#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2018-04-15 01:51:33
####################################################

import json
import requests
import re
# from city import city

def get_wea(wdata=None):
    wea = []
    wea.append(wdata["date"])
    wea.append(wdata["type"])
    high = wdata["high"]
    high = high.replace("高温","").strip()
    high = high.replace("℃", "")
    low = wdata["low"]
    low = low.replace("低温","").strip()
    low = low.replace("℃", "")
    wea.append(high)
    wea.append(low)
    fengxiang = wdata.get("fengxiang", None) or wdata.get("fx", None)
    wea.append(fengxiang)
    fengli = wdata.get("fengli", None) or wdata.get("fl", None)
    fengli = re.findall("<!\[CDATA\[(.*级)\]\]>", fengli)
    if fengli:
        fengli = fengli[0]
    wea.append(fengli)
    return wea

def get_data(city_name):
    #构造网址
    etouchUrl = "http://wthrcdn.etouch.cn/"
    weatherJsonUrl = etouchUrl + "weather_mini?city=" + city_name
    final = []
    try:
        #获取并下载页面，其内容会保存在respons.text成员变量里面
        response = requests.get(weatherJsonUrl)
        #如果请求失败的话就会抛出异常
        response.raise_for_status()
        #将json文件格式导入成python的格式  
        weatherData = json.loads(response.text)
        #import pprint
        #pprnt.pprint(weatherData)
        data = weatherData.get("data")
        yesterday = data.get("yesterday")
        final.append(get_wea(yesterday))
        forecast = data["forecast"]
        for day in data.get("forecast"):
            day = get_wea(day)
            final.append(day)
        print("#" * 60)
        print("%s" % (city_name))
        for day in final:
            print(day)
        print("#" * 60)
    except Exception as reason:
        print("%s" % reason)

def app_func():
    city_list = ["太康","通许","扶沟"]
    # city_list = ["太康"]
    for city_name in city_list:
        get_data(city_name)

if __name__ == "__main__":
    app_func()

