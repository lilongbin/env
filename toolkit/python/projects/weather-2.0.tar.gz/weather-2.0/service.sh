#! /bin/bash
# 2018-04-16 20:51:23

function weather()
{
	local script_abspath=/home/longbin/.vim/tools/bin/weather/weather.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

