#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'weather',
	     version      = '2.0',
	     py_modules   = ['weather', 'city', 'etouch', 'draw'],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'get weather infomation',
	    )
