#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2018-04-14 21:49:05
####################################################

import random
import re
import socket
import time
import csv
import http.client
import requests
from bs4 import BeautifulSoup

import draw
# from city import city

city = {
       "太康": "101181403",
       "扶沟": "101181402",
       "通许": "101180804",
       }

def get_html(url, data=None):
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate, sdch',
        'Accept-Language': 'zh-CN,zh;q=0.8',
        'Connection': 'keep-alive',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.235'
            }
    timeout = random.choice(range(80, 180))
    while True:
        try:
            rep = requests.get(url, headers=headers, timeout=timeout)
            rep.encoding = "utf-8"
            break
        except socket.timeout as reason:
            print("3: ", reason)
            time.sleep(random.choice(range(8,15)))
        except socket.error as reason:
            print("4: ", reason)
            time.sleep(random.choice(range(20,60)))
        except http.client.BadStatusLine as reason:
            print("5: ", reason)
            time.sleep(random.choice(range(30,80)))
        except http.client.IncompleteRead as reason:
            print("6: ", reason)
            time.sleep(random.choice(range(5,15)))
    return rep.text

def get__1d_data(html_txt):
    final = []
    bs = BeautifulSoup(html_txt, "html.parser")
    body = bs.body
    # print(body)
    data = body.find_all("script")
    # data = body.find("div", {"id":"40d"})
    info = re.compile(r"[^=]*=(.*)")
    temp = ''
    for script in data:
        if "var hour3data=" not in str(script):
            continue
        # print(script)
        temp = str(script).lstrip("<script>").rstrip("</script>")
        temp = info.findall(temp)[0]
        temp = temp.replace("℃", "")
        temp = eval(temp)
        temp = temp["1d"]
    for day in temp:
        day = day.split(",")
        # "14日20时,n01,多云,12℃,西风,<3级,0"
        day = [day[i] for i in [0,2,3] ]
        # day = [day[i] for i in [0,2,3,4,5] ]
        # print(day)
        final.append(day)
    return final

def get__7d_data(html_txt):
    final = []
    bs = BeautifulSoup(html_txt, "html.parser")
    body = bs.body
    # print(body)
    data = body.find("div", {"id":"7d"})
    # data = body.find("div", {"id":"40d"})
    ul = data.find("ul")
    li = ul.find_all("li")

    for day in li:
        temp = []
        date = day.find("h1").string
        temp.append(date)
        info = day.find_all("p")
        temp.append(info[0].string)
        if info[1].find("span") is None:
            temperature_high = None
        else:
            temperature_high = info[1].find("span").string
            temperature_high = temperature_high.replace("℃", "")
        temperature_low = info[1].find("i").string
        temperature_low = temperature_low.replace("℃", "")
        temp.append(temperature_high)
        temp.append(temperature_low)
        final.append(temp)
    return final

def get_15d_data(html_txt):
    final = []
    bs = BeautifulSoup(html_txt, "html.parser")
    body = bs.body
    # print(body)
    data = body.find("div", {"id":"15d"})
    # data = body.find("div", {"id":"40d"})
    ul = data.find("ul")
    li = ul.find_all("li")

    for day in li:
        temp = []
        date = day.find("span", {"class":"time"}).string
        temp.append(date)
        wea  = day.find("span", {"class":"wea"}).string
        temp.append(wea)
        wind = day.find("span", {"class":"wind"}).string
        wind1 = day.find("span", {"class":"wind1"}).string
        info = day.find_all("span")
        #temp.append(info[0].string)
        temperature = re.sub("<[/]*em>", "", str(info[2]))
        temperature = re.sub("<[/]*span[^>]*>", "", temperature)
        if not temperature:
           temperature = None
        temperature = temperature.split("/")
        temperature_low = temperature[1]
        temperature_low = temperature_low.replace("℃", "")
        temperature_high = temperature[0]
        temperature_high = temperature_high.replace("℃", "")
        temp.append(temperature_high)
        temp.append(temperature_low)
        #temp.append(info[1].string)
        #temp.append(info[3].string)
        #temp.append(info[4].string)
        #temp.append(wind)
        #temp.append(wind1)
        final.append(temp)
    return final

def get_40d_data(html_txt):
    final = []
    bs = BeautifulSoup(html_txt, "html.parser")
    body = bs.body
    # print(body)
    # data = body.find("div", {"id":"7d"})
    data = body.find("div", {"id":"40d"})
    ul = data.find("ul")
    li = ul.find_all("li")

    for day in li:
        temp = []
        date = day.find("h1").string
        temp.append(date)
        info = day.find_all("p")
        temp.append(info[0].string)
        if info[1].find("span") is None:
            temperature_high = None
        else:
            temperature_high = info[1].find("span").string
            temperature_high = temperature_high.replace("℃", "")
        temperature_low = info[1].find("i").string
        temperature_low = temperature_low.replace("℃", "")
        temp.append(temperature_high)
        temp.append(temperature_low)
        final.append(temp)
    return final

def write_data(data, filename):
    return
    with open(filename, 'a', errors="ignore", newline="") as fd:
        f_csv = csv.writer(fd)
        f_csv.writerows(data)

def get_url(city_name="", dayid="7d"):
    # city_name = input("Please input city name: ")
    city_name = city_name
    city_code = city.get(city_name, None)
    if not city_code:
        return None
    weatherUrl = "http://www.weather.com.cn/weather"
    if dayid == "1d":
        url = weatherUrl + "1d/%s.shtml" % city_code
    elif dayid == "15d":
        url = weatherUrl + "15d/%s.shtml" % city_code
    elif dayid == "40d":
        url = weatherUrl + "40d/%s.shtml" % city_code
    else:
        url = weatherUrl + "/%s.shtml" % city_code
    print(url)
    return url

def get_weather(city_name, dayid="7d"):
    print("#" * 60)
    print("[%s] %s: " % (city_name, dayid))
    url = get_url(city_name, dayid)
    html = get_html(url)
    if dayid == "1d":
        result = get__1d_data(html)
    elif dayid == "15d":
        result = get_15d_data(html)
    elif dayid == "40d":
        result = get_40d_data(html)
    else:
        result = get__7d_data(html)
    for i in result:
        print(i)
    print("#" * 60)
    return result

def app_func():
    # city_list = ["太康","通许","扶沟"]
    city_list = ["太康"]
    for city_name in city_list:
        w7d = get_weather(city_name, "7d")
        draw.draw(w7d)
        w15d = get_weather(city_name, "15d")
        draw.draw(w15d)
        w1d = get_weather(city_name, "1d")
        draw.draw(w1d)
        write_data(w1d, "weather.csv")

if __name__ == "__main__":
    app_func()


