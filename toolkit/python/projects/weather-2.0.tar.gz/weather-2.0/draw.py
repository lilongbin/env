#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2018-04-15 04:07:03
####################################################

import re
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator,FuncFormatter

def draw(weather_data=""):
    weather_type = {
            "晴":     "sunny",
            "多云":   "cloudy",
            "阴":     "",
            "阵雨":   "rain",
            "雷阵雨": "",
            "雷阵雨伴有冰雹": "",
            "雨夹雪": "",
            "小雨":   "rain",
            "中雨":   "rain",
            "大雨":   "rain",
            "暴雨":   "rain",
            "大暴雨": "rain",
            "特大暴雨": "",
            "阵雪":   "snow",
            "小雪":   "snow",
            "中雪":   "snow",
            "大雪":   "snow",
            "暴雪":   "snow",
            "雾":     "",
            "冻雨":   "",
            "沙尘暴": "",
            "小雨-中雨": "",
            "中雨-大雨": "",
            "大雨-暴雨": "",
            "暴雨-大暴雨": "",
            "大暴雨-特大暴雨": "",
            "小雪-中雪": "",
            "中雪-大雪": "",
            "大雪-暴雪": "",
            "浮尘":   "",
            "扬沙":   "",
            "强沙尘暴": "",
            "霾":     "",
            }
    data = weather_data
    def ana_wea_data(weather_data):
        weatherd = {}
        weatherd["tem_low"]  = []
        weatherd["tem_high"] = []
        weatherd["type"]     = []
        weatherd["date"]     = []
        for line in data:
            try: tem_low = int(line[3])
            except: tem_low = ""
            weatherd["tem_low"].append(tem_low)
            try: tem_high = int(line[2])
            except: tem_high = ""
            weatherd["tem_high"].append(tem_high)
            wtype = line[1]
            wtype = weather_type.get(wtype, "")
            weatherd["type"].append(wtype)
            date = re.findall("([0-9]{2,2})", line[0])
            if date:
                date = "".join(date)
            else:
                date = "0"
            weatherd["date"].append(date)
        # 对空数据进行处理
        for key in ["tem_low", "tem_high"]:
            for indx,var in enumerate(weatherd[key]):
                if "" == var:
                    weatherd[key][indx] = 0
            for indx,var in enumerate(weatherd[key]):
                if 0 == var:
                    weatherd[key][indx] = \
                        sum(weatherd[key])/len(weatherd[key])
        return weatherd
    weatherd = ana_wea_data(data)

    # 通过rcParams设置全局横纵轴字体大小
    mpl.rcParams['xtick.labelsize'] = 10
    mpl.rcParams['ytick.labelsize'] = 10
    # 用来正常显示中文标签
    # plt.rcParams['font.sans-serif']=['SimHei']
    # 用来正常显示负号
    # plt.rcParams['axes.unicode_minus']=False
    
    # figure()指定图表名称
    fig = plt.figure('weather', dpi=128)
    plt.xlabel("date")
    plt.ylabel("temperature(℃)")
    plt.title("weather")
    plt.tick_params(axis='both',which='major',labelsize=10)
    plt.grid()
    
    def x_formatter(x, pos):
        for indx,date in enumerate(weatherd["date"]):
            # print(x, date)
            if int(x) == int(indx):
                return date+":"+weatherd["type"][indx]
    ax = plt.gca()
    # ax.xaxis.set_major_locator(MultipleLocator(1))
    # 主刻度文本用x_formmater函数计算
    ax.xaxis.set_major_formatter(FuncFormatter(x_formatter))
    
    x_len = len(weatherd["date"])
    x = np.linspace(0, x_len, x_len, endpoint=False)
    # 画模型的图，plot函数默认画连线图
    # plt.figure('model')
    plt.plot(x, weatherd["tem_high"], label="low",
                marker="o", markersize=4,
                linestyle="--", linewidth=2, color="r",
                markeredgecolor="black",
                markerfacecolor='white')
    if sum(weatherd["tem_low"]) != 0:
        # 如果没有获取到数据不画图
        plt.plot(x, weatherd["tem_low"], label="high",
                    marker="o", markersize=4,
                    linestyle="--", linewidth=2, color="b",
                    markeredgecolor="black",
                    markerfacecolor='white')
        plt.legend(["high", "low"])
    fig.autofmt_xdate()
    
    # 一定要加上这句才能让画好的图显示在屏幕上
    plt.show()
    
    # 将当前figure的图保存到文件result.png
    # plt.savefig('result.png')
    return

def draw_test():
    data = [
            ['14日星期六', '多云', '17', '5', '北风', '<3级'],
            ['15日星期天', '多云', '17', '4', '北风', '<3级'],
            ['16日星期一', '多云', '19', '5', '南风', '<3级'],
            ['17日星期二', '晴', '21', '6', '南风', '<3级'],
            ['18日星期三', '晴', '23', '9', '南风', '<3级'],
            ['19日星期四', '多云', '25', '10', '南风', '<3级'],
            ]
    draw(data)

if __name__ == "__main__":
    draw_test()

