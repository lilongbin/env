#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'logfilter',
	     version      = '2.4',
	     py_modules   = ['logfilter', 'config', 'rule', 'cli',],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@aptiv.com',
	     url          = 'www.aptiv.com',
	     description  = 'log analyse assistant',
	    )
