#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-09-22 21:03:58
####################################################

import os
import sys
import re

from config import Rules
g_dbglog = False
g_digitletters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

def usage():
    helpinfo = """
Usage:
    logaa  <filename>
    """
    print("%s" % helpinfo)

class FilterRule(object):
    def __init__(self, filename, rules):
        self.raw_file = filename
        self.out_file = self.raw_file + ".html"
        self.filterRules = self.init_rule(rules)
    
    def init_rule(self, rules):
        if g_dbglog: print(rules)
        for idx,frule in enumerate(rules):
            if g_dbglog: print(frule)
            keyword = frule.get("keyword")
            rulename = "st_"
            for chr in keyword:
                if chr in g_digitletters:
                    rulename += chr
            rules[idx]["rulename"] = rulename
            # print("keyword=%s" % keyword)

            ftype = frule.get("type")
            if "re" == ftype:
                # compile
                re_kw = re.compile("(%s)" % keyword, re.I)
                rules[idx]["re_keyword"] = re_kw
            else:
                ftype = "normal"
                rules[idx]["type"] = ftype

            bgcolor = frule.get("bg")
            if bgcolor:
                bgcolor = "background-color:%s" % bgcolor
            else:
                bgcolor = ""
            rules[idx]["bgcolor"] = bgcolor

            # fgcolor = frule.get("fg")
            fgcolor = frule.get("fg")
            if fgcolor:
                fgcolor = "color:%s" % fgcolor
            else:
                fgcolor = ""
            rules[idx]["fgcolor"] = fgcolor

            # doSearch
            doSearch = frule.get("doSearch")
            if doSearch == "false":
                doSearch = False
            else:
                doSearch = True
            rules[idx]["doSearch"] = doSearch

            # matchCase
            matchCase = frule.get("matchCase")
            if matchCase == "true":
                matchCase = True
            else:
                matchCase = False
            rules[idx]["matchCase"] = matchCase
        rules.reverse()
        if g_dbglog: print(rules)
        return rules
    
    def filter_proc(self, linenm, line=""):
        if not line.strip():
            return False
        matchwords =  None
        for frule in self.filterRules:
            if False == frule.get("doSearch"):
                continue
            # if g_dbglog: print(frule)
            if "re" != frule.get("type"):
                # normal
                keyword = frule.get("keyword")
                if -1 != line.find(keyword):
                    matchwords = ["%s" % keyword,]
            else:
                # re
                re_kw = frule.get("re_keyword")
                matchwords = re_kw.findall(line)
            if matchwords:
                rulename = frule.get("rulename")
                select = frule.get("select")
                if "line" == select:
                    line = "<%s>%s</%s>" % (rulename, line, rulename)
                else: #"word" == select:
                    # print(matchwords[0])
                    word = matchwords[0]
                    # for word in matchwords[0]:
                    if word:
                        repl = "<%s>%s</%s>" % (rulename, word, rulename)
                        line = line.replace(word, repl)
                line = "line %5d: %s<br>" % (linenm, line)
                if g_dbglog: print(line)
                return line
        else:
            return False
    
    def add_html_header(self):
        header="""<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">"""
        with open(self.out_file, "w") as wfd:
            if g_dbglog: print("add header: \n%s" % header)
            wfd.write(header + os.linesep)
        self.add_html_style()
        header_tail="""<title>%s</title>
</head>
<body>
<h1>%s</h1>""" % (self.out_file, self.raw_file)
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add header_tail: \n%s" % header_tail)
            wfd.write(header_tail + os.linesep)
    
    def add_html_style(self):
        mystyles = ""
        for frule in self.filterRules:
            style = ""
            rulename = frule.get("rulename")
            bgcolor = frule.get("bgcolor")
            fgcolor = frule.get("fgcolor")
            style += bgcolor
            if bgcolor:
                style += ";"
            style += fgcolor
            mystyles += "\n%s { %s }" % (rulename, style)
        html_style = """<style type="text/css"> %s \n</style>""" % mystyles
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add style: \n%s" % html_style)
            wfd.write(html_style + os.linesep)

    def add_html_body(self):
        rfd = open(self.raw_file)
        wfd = open(self.out_file, "a+")
        linenm = 0
        for line in rfd:
            linenm += 1
            # print(line)
            if not line.strip():
                continue
            result = self.filter_proc(linenm, line)
            if result:
                wfd.write(result + os.linesep)
        if g_dbglog: print("add body complete.")
        rfd.close()
        wfd.close()
    
    def add_html_footer(self):
        footer = """
    </body>
    </html>
        """
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add footer: \n%s" % footer)
            wfd.write(footer + os.linesep)
    
    def run(self):
        self.add_html_header()
        self.add_html_body()
        self.add_html_footer()
        print("result restore to file: %s" % self.out_file)

def proc(filename=""):
    if not filename.strip():
        print("Error: invalid parameter.")
        return
    if not os.path.isfile(filename):
        print("Error: %s: No such file." % filename)
        return
    fr = FilterRule(filename, Rules)
    fr.run()

if __name__ == "__main__":
    filename = ""
    if len(sys.argv) < 2:
        usage()
        sys.exit(0)
    if sys.argv[1].lower() in ["-h", "--help", "?"]:
        usage()
        sys.exit(0)
    filename = sys.argv[1]
    proc(filename)

