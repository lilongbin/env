#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-03-28 15:38:20
####################################################

import sys

class encoder(object):
    def __init__(self):
        print("init")
    def encode(self, codes):
        print(codes)

