#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-03-28 15:38:20
####################################################

import sys
import signal
import database
try:
    input = raw_input
except: pass

class decoder(object):
    def __init__(self):
        db = database.DataBase()
        self.globaldb = db.getdb()
        self.debug = True
        # print("init OK")

    def search(self, key):
        # if self.debug: print("search: %s" % key)
        value = None
        # signle byte
        if 0x00 <= key <= 0x7F:
            value = chr(key)
            return value
        # 4 bytes
        if key in self.globaldb:
            value = self.globaldb[key]
            return value
        return value

    def decode(self, codes):
        # if self.debug: print("decode: ", codes)
        res = []
        precode = ""
        wbyte = 0
        for code in codes:
            wbyte += 1
            code = precode + code
            precode = ""
            try:
                key = int(code, 16)
            except Exception as reason:
                print("ERROR: .decode:%s %s" % (code, reason))
                return
            value = self.search(key)
            if value:
                if self.debug: print("decode %s: \'%s\'" % (code, value))
                res.append(value)
                wbyte = 0
            else:
                precode = code
                if wbyte >= 2:
                    print("decode %s: failed" % code)
                    wbyte = 0
                    precode = ""
            # if self.debug: print("decode %s: %s" % (str(hex(key)).upper(), value))
        print("".join(res))

def sig_ctl_c(a, b):
    print("")
    sys.exit(2)

def decodefunc(codes=()):
    msg = "\033[01mDecode: \033[0m"
    dec = decoder()
    if codes:
        dec.decode(codes)
        return

    print("Please type the codes string you want to decode, or q to quit.")
    print("eg: B0 B2 BC AA D0 C7 D0 C5 CF A2")
    print("eg: BDD3 C8 EB B5 E3 3A 20 53 47 4D 20 4F 6E 53 74 61 72 20 30 35 33 39 0A C3 DC C2 EB 3A 20 42 41 77 36 70 38 6B 6E 0A B5 B1 C7 B0 CD F8 C2 E7 D7 B4 CC AC A3 BA 34 47 20 4C 54 45 00 00 00 00 00")
    while True:
        signal.signal(signal.SIGINT, sig_ctl_c)
        signal.signal(signal.SIGQUIT, sig_ctl_c)
        try:
            line = input(msg)
        except Exception as reason:
            print("input error:", reason)
            print("")
            break
        line = line.strip().lower()
        if not line: continue
        if line == "q": break
        try:
            dec.decode(line.split())
        except Exception as reason:
            print("ERROR: decode: %s" % reason)
            break
        print("")

