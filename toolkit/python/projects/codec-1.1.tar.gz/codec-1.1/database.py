#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-03-28 18:20:05
####################################################

import os
import sys
import shelve

if os.path.dirname(__file__):
    cur_dir = os.path.dirname(__file__) + '/'
else:
    cur_dir = './'

class DataBase(object):
    def __init__(self, srcfile="gb18030.txt", datafile="gb18030.dat"):
        self.srcfile = cur_dir + srcfile
        self.datafile = cur_dir + datafile
        self.globaldb = {}

    def _dbinit_(self):
        if not os.path.isfile(self.srcfile):
            print("ERROR: %s: No such file" % self.srcfile)
        with open(self.srcfile) as db:
            for line in db:
                # print(line)
                line = line.strip().split()
                if not line or len(line) != 2: continue
                try:
                    key = int(line[-1], 16)
                    value = line[0]
                except Exception as reason:
                    print("ERROR: .dbinit: %s" % reason)
                    continue
                self.globaldb[key] = value
        # print(self.globaldb)
        # print("dbinit OK")
    
    def dbdump(self):
        self._dbinit_()
        if not self.globaldb: return self.globaldb
        try:
            fd = shelve.open(self.datafile)
            fd['db'] = self.globaldb
            fd.close()
        except Exception as reason:
            print("ERROR: .dbdump: %s" % reason)
            sys.exit(1)
        return self.globaldb
    
    def dbload(self, filename=""):
        if not filename:
            filename = self.datafile
        # print(filename)
        # filename = os.sep.join([os.getenv("HOME"), ".codec.d", filename])
        try:
            fd = shelve.open(filename)
            self.globaldb = fd['db']
            fd.close()
            # print("dbload OK")
        except Exception as reason:
            print("ERROR: .dbload: %s" % reason)
            self.globaldb = {}                                                                                              
            if os.path.isfile(filename):
                os.remove(filename)
        return self.globaldb

    def getdb(self):
        if self.globaldb:
            return self.globaldb
        if not os.path.isfile(self.datafile):
            return self.dbdump()
        return self.dbload()

if __name__ == "__main__":
    db = DataBase()
    db.getdb()

