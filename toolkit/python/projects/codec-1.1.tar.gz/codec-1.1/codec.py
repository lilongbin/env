#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-03-28 15:29:08
####################################################

import os
import sys
import decoder
import encoder
import database


help_info = """Usage:
    code [--init | --help | -h | codes ]
    code
"""

if __name__ == "__main__":
    codes = []
    if len(sys.argv) >= 2:
        if sys.argv[1] == "--init":
            database.DataBase().dbdump()
            sys.exit(0)
        elif sys.argv[1].lower() in ["--help", "-h"]:
            print(help_info)
            sys.exit(0)
        else:
            codes = sys.argv[1:]
    decoder.decodefunc(codes)

