#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'codec',
	     version      = '1.1',
	     py_modules   = ['codec', 'database', 'decoder', 'encoder',],
	     package_data = {'': ["*.txt"],},
	     author       = 'longbin',
	     author_email = 'longbin.li@aptiv.com',
	     url          = 'www.aptiv.com',
	     description  = 'decode encoding to Chinese',
	    )
