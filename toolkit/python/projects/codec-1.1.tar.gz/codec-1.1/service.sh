#! /bin/bash
# 2019-12-23 11:13:14

function codec()
{
	local script_abspath=/home/user/toolkit/bin/codec/codec.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

