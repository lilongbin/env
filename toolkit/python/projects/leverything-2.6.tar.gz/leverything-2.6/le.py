#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2017-11-16 00:29:08
####################################################

import os
import sys
import everything
import dbinit

def le(filename=[]):
    everything.search(filename)

help_info = """Usage:
    le [--init | --help | -h | filename ]
    le
"""

if __name__ == "__main__":
    filename = []
    if len(sys.argv) >= 2:
        if sys.argv[1] == "--init":
            dbinit.dbinit()
            sys.exit(0)
        elif sys.argv[1].lower() in ["--help", "-h"]:
            print(help_info)
            sys.exit(0)
        else:
            filename = sys.argv[1:]
    le(filename)

