try:
    import colorama
    colorama.init(autoreset=True)
except: pass

def setcolor(msg, color='blue'):
    try:
        color_value = eval("colorama.Fore.%s" % color.upper())
        wrapped_msg = colorama.Style.RESET_ALL + color_value + msg + colorama.Style.RESET_ALL
    except:
        wrapped_msg = msg
    return wrapped_msg

def test():
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
        print("color %s: %s" % (color, setcolor(color, color)))

if __name__ == '__main__':
    test()
