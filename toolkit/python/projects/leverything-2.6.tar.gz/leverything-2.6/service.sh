#! /bin/bash
# 2019-01-30 16:29:44

function le()
{
	local script_abspath=/home/user/toolkit/bin/le/le.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

