#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2017-11-16 00:20:05
####################################################

import everything

def dbinit():
    everything.updatedb()

if __name__ == "__main__":
    dbinit()

