#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'leverything',
	     version      = '2.6',
	     py_modules   = ['le', 'dbinit', 'everything', 'walk', 'setcolor',],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'search everything',
	    )
