#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2017-11-14 23:38:42
####################################################

import os
import sys
import re
import signal
# import shelve
import time
try:
    import thread
except:
    import _thread as thread

import walk
import setcolor

try:
    input = raw_input
except:
    pass

digits = '0123456789'
letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

class Everything(object):
    def __init__(self):
        self.globaldb = {}
        self.dblnsplitsep = ","
        self.hilightmatch = True
        self.dbdirname =  os.sep.join([os.getenv("HOME"), ".le.d"])
        self.dbfilename = os.sep.join([self.dbdirname, "le.dat"])
        self.sysversion = sys.version
        self.dbconf = os.sep.join([self.dbdirname, "le.conf"])
        self.userelpath = True
        self.helpinfo = """
        Abcd.*f     Not all characters are lower case will use regular expression search;
        abcd.*f     all characters are lower case will use regular expression and ignore case search;
        abc def     will treat as abc.*def regular expression to search;
        all patterns will do whole match first then regular expression search;
        """

    def setconf(self):
        self.srcrootpath = os.getcwd()
        config = ""
        config = config + "srcrootpath = " + self.srcrootpath + os.linesep
        with open(self.dbconf, "w") as wfd:
            wfd.write(config)

    def getconf(self):
        self.srcrootpath = "."
        filename = self.dbconf
        if not os.path.isfile(filename):
            print("use --init option to init data base first")
            sys.exit(1)
        with open(filename, "r") as rfd:
            for line in rfd:
                line = line.strip()
                if not line:
                    continue
                line = [v.strip() for v in line.split("=")]
                if len(line) != 2:
                    continue
                key = line[0]
                value = line[1]
                if key == "srcrootpath":
                    self.srcrootpath = value
            pass
        # print("srcrootpath = %s" % self.srcrootpath)

    def dbsave(self):
        dirname =  self.dbdirname
        filename = self.dbfilename
        lnsplitsep = self.dblnsplitsep
        if not os.path.isdir(dirname):
            os.mkdir(dirname)
        print("writing to db file...")
        #fdb = shelve.open(filename, writeback=True)
        ## print(self.globaldb)
        #fdb['db'] = {}
        #fdb['db'] = self.globaldb
        #fdb.close()
        with open(filename, "w") as wfd:
            for key in self.globaldb:
                line = key + lnsplitsep
                line += lnsplitsep.join(self.globaldb[key]) + os.linesep
                # print(line)
                wfd.write(line)

    def dbload(self):
        filename = self.dbfilename
        lnsplitsep = self.dblnsplitsep
        if not os.path.isfile(filename):
            print("use --init option to init data base first")
            sys.exit(1)
        try:
            self.getconf()
        except Exception as reason:
            print("ERROR: .getconf: %s" % reason)
        print("srcrootpath: %s" % self.srcrootpath)
        if self.srcrootpath != ".":
            os.chdir(self.srcrootpath)
        try:
            #fdb = shelve.open(filename)
            #self.globaldb = fdb['db']
            #fdb.close()
            rfd = open(filename, "r")
            for line in rfd:
                line = line.strip()
                if not line: continue
                line = line.split(lnsplitsep)
                self.globaldb[line[0]] = line[1::]
        except Exception as reason:
            print("ERROR: .dbload: %s" % reason)
            self.globaldb = {}
            if os.path.isfile(filename):
                os.remove(filename)
            sys.exit(1)

    def dbinit(self):
        print(self.sysversion)
        print("updatedb...")
        if self.userelpath:
            # use relative path
            rootpath = "."
        else:
            # use absolute path
            rootpath = os.getcwd()
        for filename in walk.getfiles("."):
            self.dbadd(rootpath, filename)
        self.dbsave()
        self.setconf()
        # self.dbshow()
        print("OK")

    def help(self):
        print("%s" % self.helpinfo)

    def dbshow(self):
        for key in self.globaldb:
            print("%s: " % key, self.globaldb[key])

    def dbadd(self, root, path):
        pathseplst = path.strip().split(os.sep)
        if not len(pathseplst):
            return
        for i,word in enumerate(pathseplst):
            if word == '.':
                continue
            if pathseplst[0] == ".":
                pathseplst[0] = root
            pathname = os.sep.join(pathseplst[:i+1])
            if os.path.isdir(pathname):
                pathname += os.sep
            if word in self.globaldb:
                if pathname not in self.globaldb[word]:
                    self.globaldb[word].append(pathname)
            else:
                self.globaldb[word] = [pathname]

    def pathshow(self, filename):
        if (not os.path.exists(filename)):
            print("%s: %s:No such file" % (setcolor.setcolor("Warning", "red"), filename))
            return
        ftype = " "
        if os.path.isdir(filename):
            ftype = "d"
        if os.path.islink(filename):
            ftype = "l"
        if os.path.isfile(filename):
            ftype = "-"
        words = filename.strip(os.sep).split(os.sep)
        if not words: return
        basename = os.path.basename(filename)
        location = os.path.dirname(filename)
        # mtime = time.strftime("%Y-%m-%d %H:%M:%S" , time.gmtime(os.path.getmtime(filename)))
        mtime = ""
        fsize = os.path.getsize(filename)
        print("%s %-20s %6s %s  %s" % (ftype, basename, fsize, mtime, location))

    def showmatchfile(self, dbkey, matchword):
        for filename in self.globaldb[dbkey]:
            if self.hilightmatch:
                i = filename.rindex(matchword)
                cfilename = filename[:i] + setcolor.setcolor(matchword) + filename[i+len(matchword):]
                print(cfilename)
            else:
                self.pathshow(filename)

    def search(self, line):
        if not line:
            return
        lenth = 0
        # if all characters in S are alphabetic, re ignore case
        ignorecase = line.islower()
        for chr in line:
            if chr in letters or chr in ".":
                lenth += 1
            if chr in "*":
                lenth -= 1
        if line[0] == "*":
            line = "." + line
        line = line.replace(" ", ".*")
        if not self.globaldb:
            print("ERROR: .search: updatedb please.")
            sys.exit(1)
        for word in self.globaldb:
            # match word == line first
            if word != line:
                continue
            self.showmatchfile(word, word)
        for word in self.globaldb:
            if len(word) < lenth:
                continue
            # match word != line then
            if word == line:
                continue
            if ignorecase:
                matchi = re.search(line, word, re.I)
            else:
                matchi = re.search(line, word)
            if not matchi:
                continue
            matchw = word[matchi.span()[0]:matchi.span()[1]]
            self.showmatchfile(word, matchw)

def sig_ctl_c(a, b):
    print("")
    sys.exit(2)

def updatedb():
    signal.signal(signal.SIGINT, sig_ctl_c)
    ev = Everything()
    ev.dbinit()

def search(filename=()):
    signal.signal(signal.SIGINT, sig_ctl_c)
    ev = Everything()
    msg = "\033[01mSearch: \033[0m"

    # command mode
    if filename:
        ev.dbload()
        line = " ".join(filename)
        line = line.strip()
        print("{}{}".format(msg, line))
        try:
            ev.search(line)
        except Exception as reason:
            print("ERROR: search: %s" % reason)
        print("")
        return

    # interactive mode
    ev.dbload()
    # thread.start_new_thread(ev.dbload, tuple())
    print("Please type the file name you want to search, or q to quit.")
    while True:
        line = input(msg).strip()
        if not line:
            continue
        if line.lower() == "q":
            break
        try:
            ev.search(line)
        except Exception as reason:
            print("ERROR: search: %s" % reason)
            break
        print("")

if __name__ == "__main__":
    search(sys.argv[1:])

