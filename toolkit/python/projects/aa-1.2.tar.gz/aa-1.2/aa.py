#! /usr/bin/env python
# coding=utf-8
# longbin beangr@163.com

import os
import sys
import time
import re
import mycli
import cli
import setcolor

if os.path.dirname(__file__):
    cur_dir = os.path.dirname(__file__) + '/'
else:
    cur_dir = './'
try:
    aafile_dir = os.environ['HOME'] + "/toolkit/bible"
except:
    aafile_dir = os.environ['HOMEPATH'] + r"\toolkit\bible"

try: input = raw_input
except: pass

def get_user_str(msg):
    # need return utf-8 encoding
    return mycli.CLI_get_line(msg)

class AA(object):
    def __init__(self):
        # self.aafile = cur_dir + 'db/aa.txt'
        self.aafile = aafile_dir + '/tips.txt'
        self.ua_title = ''
        self.ua_lines = ''
        self.linesep = '\r\n'
        self.cli = cli.CLI()
        self.printf = self.cli.printf
        self.init_check()
    def init_check(self):
        if not os.path.isfile(self.aafile):
            self.show_line('%s: No such file.' % self.aafile)
            sys.exit()
    def pause(self, prompt_msg):
        self.cli.printf(prompt_msg)
        ch = self.cli.getch()
        self.cli.printf('\b \b' * len(prompt_msg))
        return ch
    def get_line(self, prompt_msg=''):
        return get_user_str(prompt_msg)
    def get_ua_tag(self):
        self.ua_tag = 'A'+time.strftime("%Y%m%d%H%M%S")
        return self.ua_tag
    def get_ua_title(self):
        prompt_msg = "Title: "
        self.ua_title = self.get_line(prompt_msg).strip()
        if self.ua_title.lower() in ['q', 'quit', b'q']:
            sys.exit(0)
        return self.ua_title
    def get_lines(self, prompt_msg='', line_header=''):
        linesep = self.linesep + line_header
        str_lst = []
        self.printf("Please type isEOF to complete input.\n")
        self.printf("%s\n" % prompt_msg),
        while True:
            user_input = raw_input().rstrip()
            if user_input == "isEOF":break
            if user_input: str_lst.append(user_input)
        self.ua_lines = line_header + linesep.join(str_lst)
        return self.ua_lines
    def draw_split_line(self, element='*'):
        self.printf("%s\n" % (element * 60))
    def write_lines(self, lines):
        file = self.aafile
        dir = os.path.dirname(file)
        if not os.path.isdir(dir):
            os.mkdir(dir)
        with open(file, 'a+') as fd:
            fd.write(lines)
        self.show_line('Write completed.')
    def add(self):
        self.show_line("\nAdd new contents")
        linesep = self.linesep
        atag = self.get_ua_tag()
        title = 'Q: ' + self.get_ua_title() + ' :' + atag + ':'
        ahead = atag + ":START"
        aend = atag + ":END"
        prompt_msg = "Answer:"
        lines = self.get_lines(prompt_msg, line_header='\t')
        # lines = lines.encode('utf-8')
        lines = title + linesep +\
                ahead + linesep +\
                self.ua_title + linesep +\
                lines + linesep +\
                aend + linesep
        self.printf(lines+'\n')
        prompt_msg = "Will write above lines to %s ?<Y/n>" % self.aafile
        user_input = self.get_line(prompt_msg)
        if user_input.lower() != "n":
            self.write_lines(linesep + lines)
    def show_line(self, line=''):
        self.printf("%s\n" % line.rstrip())
    def get_keywords(self):
        prompt_msg = 'Q: '
        line = self.get_line(prompt_msg).strip()
        if line.lower() in ['q', 'quit', b'q']:
            sys.exit(0)
        keywords = line.split()
        return keywords
    def get_all_atags(self):
        ahead = re.compile('^A[0-9]{14}:START')
        file = self.aafile
        atags = []
        with open(file, 'r') as fd:
            for line in fd:
                if line[0] != 'A':
                    continue
                if ahead.match(line):
                    atags.append(line.split(':')[0])
        return atags
    def sort_kw_atags(self, kwdict):
        if len(kwdict) == 1 and not kwdict.values()[0]:
            self.best_atag = ''
            self.best_atag_cnt = 0
            self.sorted_atags = []
            return
        'kwdict like this:'
        '''
        0: [a1, a2],
        1: [a2, a3],
        2: [a2, a4],
        3: [a2, a3],
        '''
        'from raw dict to counter, dcounter like this:'
        'a1:1, a2:4, a3:2, a4:1'
        'use the counter number as the key, get the result'
        '4:[a2], 3:[], 2:[a3], 1:[a1, a4]'
        'a2, a3, a1, a4'
        dcounter = {}
        for key in kwdict:
            for atag in set(kwdict[key]):
                if atag in dcounter:
                    dcounter[atag] += 1
                else:
                    dcounter[atag] = 1
        dcounter_values = []
        for atag in dcounter:
            dcounter_values.append(dcounter[atag])
        sorted_atags = []
        for cnt in range(max(dcounter_values), 0, -1):
            for atag in dcounter:
                if dcounter[atag] == cnt:
                    sorted_atags.append(atag)
        self.best_atag = sorted_atags[0]
        self.best_atag_cnt = dcounter[sorted_atags[0]]
        self.sorted_atags = sorted_atags
    def search_keyword_atags(self, keyword, atags):
        aafile = self.aafile
        ahead = re.compile('^A[0-9]{14}:START')
        aend = re.compile('^A[0-9]{14}:END')
        if not os.path.isfile(aafile):
            return 
        block_in = False
        with open(aafile) as fd:
            for line in fd:
                if not block_in and line[0] == 'A' and ahead.match(line):
                    atag = line[:line.index(":START")]
                    block_in = True
                    continue
                # if block_in and line[0] == 'A' and aend.match(line):
                if line[0]=="A" and block_in and line.strip()==atag+":END":
                    block_in = False
                    continue
                # if block_in and re.search(keyword, line):
                if block_in and -1 != line.find(keyword):
                    atags.append(atag)
                    block_in = False
    def show_infoblock_of_atag(self, atag):
        atag = atag
        aafile = self.aafile
        ahead = re.compile('^%s:START' % atag)
        aend = re.compile('^%s:END' % atag)
        if not os.path.isfile(aafile):
            return None
        block_in = False
        head_line = False
        with open(aafile) as fd:
            for line in fd:
                if line[0] == 'A' and not block_in and ahead.match(line):
                    block_in = True
                    head_line = True
                    self.show_line(atag)
                    continue
                if line[0] == 'A' and block_in and aend.match(line):
                    block_in = False
                    continue
                if block_in:
                    if head_line:
                        line = setcolor.setcolor(line,'blue')
                        head_line = False
                    self.show_line(line)
    def search(self):
        self.show_line("\nSearch answers")
        keywords = self.get_keywords()
        atags = {}
        for enum,keyword in enumerate(keywords):
            atags[enum] = []
            # atags[0]: ['Axx', 'Axx', 'Axx']
            # atags[i]: ['Aii', 'Aii', 'Aii']
            self.search_keyword_atags(keyword, atags[enum])
        #print(atags)
        for key in atags:
            if atags[key]: break
        else:
            self.show_line('No matched info was found.')
            return
        self.sort_kw_atags(atags)
        atags = self.sorted_atags
        best_atag = self.best_atag
        best_atag_cnt = self.best_atag_cnt
        self.draw_split_line()
        for atag in atags:
            self.show_infoblock_of_atag(atag)
            self.show_line()
            ch = self.pause('press any key to continue.')
            if ch.lower() == 'q': break
        self.draw_split_line()
        if best_atag_cnt >= len(keywords):
            self.show_line('\nThe recommanded answer:')
            self.show_infoblock_of_atag(best_atag)
            self.show_line()
    def clear(self):
        mycli.CLI_clear_history()
    def review(self):
        days = 3
        mytime = time.gmtime(time.time() - days*24*3600)
        atag_prefix = str(time.strftime('%Y%m%d%H%M%S',mytime))
        self.show_line('Time line: %s' % atag_prefix)
        for atag in self.get_all_atags():
            if int(atag[1:]) >= int(atag_prefix):
                self.draw_split_line()
                self.show_infoblock_of_atag(atag)
                self.draw_split_line()
                self.show_line()
                ch = self.pause('press any key to continue.')
                if ch.lower() == 'q': break

def help():
    help_info ='''\
Usage:
    aa -[a|c|h|r|s]
    The default operation is search answers.
        
    -a    add new contents to data base;
    -c    clear the history of cmd line;
    -h    show help infomation;
    -r    review history from data base;
    -s    search answers from data base;
'''
    print('%s' % help_info)

def main(argv):
    if not argv:
        args = '-s'
    else:
        args = argv[0].lower()
    func_map = {
            '-h': 'help',
            '--help': 'help',
            '-a': 'add',
            '-c': 'clear',
            '-r': 'review',
            '-s': 'search',
            }
    try:
        op = func_map[args]
    except Exception as reason:
        print("ERROR: %s: invalid param" % reason)
        help()
        return False
    if op == "help":
        help()
        return True

    aa = AA()
    op_func = 'aa.%s()' % op
    while True:
        eval(op_func)
        if op in ['clear', 'review']: break

if __name__ == '__main__':
    main(sys.argv[1:])

