#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'aa',
	     version      = '1.2',
	     py_modules   = ['aa', 'mycli', 'cli', 'setcolor'],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'ask and answer system',
	    )