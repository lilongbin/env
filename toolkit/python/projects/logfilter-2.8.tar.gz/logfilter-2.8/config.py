#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-09-20 12:52:04
####################################################

import os
from configuration import Configeration
from jsonrules import JsonRules

class RuleConfigure(object):
    def __init__(self):
        self.ruleSuffix = ".json"
        self.ruleDir = os.sep.join([os.getenv("HOME"), ".logfilter"])
        self.profile = os.sep.join([os.getenv("HOME"), ".logfilter_rc"])
        self.profileCfg = Configeration(self.profile)
        self.ruleFile = self.profileCfg.getValue("rule", "path")
        self.defaultruleFile = os.sep.join([self.ruleDir, "default"+self.ruleSuffix])
        self.currentRules = []
        self.init()

    def init(self):
        if not os.path.isdir(self.ruleDir):
            try:
                os.makedirs(self.ruleDir)
            except Exception as reason:
                print("mkdir(%s) error:%s" % (self.ruleDir, reason))
        if not self.ruleFile:
            # set default rule
            self.ruleFile = self.defaultruleFile
            self.profileCfg.setValue("rule", "path", self.ruleFile)
            self.profileCfg.write()
        self.load(self.ruleFile)

    def getRuleFileBasename(self):
        return os.path.basename(self.ruleFile)

    def getRuleFilePath(self):
        return self.ruleFile

    def getRules(self):
        return self.currentRules

    def list(self):
        #list rule files
        if not os.path.isdir(self.ruleDir):
            return
        for dirpath, dirnames, filenames in os.walk(self.ruleDir):
            for dirname in dirnames[:]:
                if len(dirname)>1 and dirname[0] == ".":
                    dirnames.remove(dirname)
            for filename in filenames:
                print("%s" % filename)

    def setRuleFile(self, ruleFile=''):
        if not ruleFile:
            ruleFile = self.ruleFile
        else:
            self.ruleFile = ruleFile
            self.profileCfg.setValue("rule", "path", self.ruleFile)
            self.profileCfg.write()
        self.load(ruleFile)

    def load(self, ruleFile=''):
        if not ruleFile:
            ruleFile = self.ruleFile
        else:
            self.ruleFile = ruleFile
        jrules = JsonRules(ruleFile)
        self.currentRules = []
        rules = jrules.getRules()
        if "style" in rules:
            self.currentRules = rules.get("style")

    def remove(self, ruleFile=''):
        try:
            os.remove(ruleFile)
        except Exception as reason:
            print("remove(%s) error: %s" % (ruleFile, reason))
        return
    def create(self, ruleFile=''):
        return
