#! /bin/bash
# 2020-04-09 20:06:27

function logfilter()
{
	local script_abspath=/home/user/.toolkit/bin/logfilter/logfilter.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python3 ${script_abspath} $*
	fi
}

