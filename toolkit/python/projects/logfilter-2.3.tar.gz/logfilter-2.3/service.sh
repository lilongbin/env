#! /bin/bash
# 2019-09-23 12:30:53

function logaa()
{
	local script_abspath=/home/user/toolkit/bin/logaa/logaa.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

