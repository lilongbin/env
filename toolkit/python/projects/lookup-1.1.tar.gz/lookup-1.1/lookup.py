#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2018-04-15 14:37:00
####################################################

import os
import sys
import re
import signal

try:
    import thread
except:
    import _thread as thread
import cli
import dbinit

cliobj = cli.CLI()

if os.path.dirname(__file__):
    cur_dir = os.path.dirname(__file__) + '/'
else:
    cur_dir = './'

class LookUp(object):
    def __init__(self, dbfile):
        self.dbfile = dbfile
        self.worddb = {}
        return

    def init(self):
        if not os.path.isfile(self.dbfile):
            print("ERROR: %s: No such file." % (self.dbfile))
            sys.exit(1)
        self.worddb = dbinit.dbload()
        # dbinit.dbshow()

    def show(self, word):
        if not self.worddb:
            return
        print("{:16s} {:s}".format(word, self.worddb.get(word, None)))
        
    def lookup(self, word):
        word = word.strip().lower()
        if not word:
            return
        if not self.worddb:
            print("ERROR: updatedb first.")
            sys.exit(1)
        if word[0] == "*":
            word = "." + word 
        word = word.replace(" ", ".*")
        if word in self.worddb:
            self.show(word)
            return
        # word = re.compile(word)
        for k in self.worddb:
            reM = re.match(word, k, re.I)
            if reM:
                self.show(k)
                continue
            interpretation = self.worddb.get(k, "")
            reM = re.search(word, interpretation, re.I)
            if reM:
                self.show(k)


def sig_ctl_c(a, b):
    print("")
    sys.exit(2)

def updatedb():
    signal.signal(signal.SIGINT, sig_ctl_c)
    rawfile = cur_dir + "db/w.txt"
    dbfile = cur_dir + "db/db.json"
    dbinit.dbdump(rawfile=rawfile, dbfile=dbfile)

def lookup(word=None):
    signal.signal(signal.SIGINT, sig_ctl_c)
    rawfile = cur_dir + "db/w.txt"
    dbfile = cur_dir + "db/db.json"
    lk = LookUp(dbfile)
    prompt = "\033[01mLookUp:\033[0m"

    # command mode
    if word:
        lk.init()
        word = " ".join(word).lower()
        print("{}{}".format(prompt, word))
        try:
            lk.lookup(word)
        except Exception as reason:
            print("ERROR: %s" % reason)
        print("")
        return

    # interactive mode
    lk.init()
    # thread.start_new_thread(lk.init, tuple())
    cliobj.set_prompt(prompt)
    help_info = {}
    for word in lk.worddb:
        help_info[word] = ""
    cliobj.set_help_info_dct(help_info)
    print("Please type the word you want to look up, or q to quit.")
    while True:
        # line = input(prompt).strip().lower()
        word = cliobj.get_line().strip().lower()
        if len(word) == 1 and ord(word[0]) == cli.CLI_KEY_CTRLD:
            print("")
            break
        if not lk.worddb:
            print("ERROR: updatedb first.")
            sys.exit(1)
        if not word:
            continue
        if word == "q":
            break
        try:
            lk.lookup(word)
        except Exception as reason:
            print("ERROR: %s" % reason)
        print("")

if __name__ == "__main__":
    lookup(sys.argv[1:])

