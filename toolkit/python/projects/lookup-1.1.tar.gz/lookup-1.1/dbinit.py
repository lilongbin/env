#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2018-04-15 13:54:34
####################################################

import os
import json

if os.path.dirname(__file__):
    cur_dir = os.path.dirname(__file__) + '/'
else:
    cur_dir = './'
rawfile = cur_dir + "db/w.txt"
dbfile = cur_dir + "db/db.json"

class DB(object):
    def __init__(self, rawfile, dbfile):
        self.rawfile = rawfile
        self.dbfile = dbfile
        self.worddb = {}

    def init(self):
        worddb = {}
        try:
            eval('print("db init ... ", end="")')
        except:
            print("db init ... "),
        fd = open(self.rawfile, "r")
        for line in fd:
            line = line.strip()
            if not line:
                continue
            line = line.split("\t")
            word = line[0]
            # interpretation = "\t".join(line[1:]).strip()
            interpretation = "{:16s} ".format(line[1]) + " ".join(line[2:]).strip()
            if word not in worddb:
                worddb[word] = interpretation
            else:
                worddb[word] += interpretation
        self.worddb = worddb
        print("\rdb init ... OK")
        return self.worddb
    
    def dbdump(self):
        self.init()
        with open(self.dbfile, "w") as wfd:
            json.dump(self.worddb, wfd, indent=4)
    
    def dbload(self):
        worddb = {}
        with open(self.dbfile, "r") as wfd:
            worddb = json.load(wfd)
        self.worddb = worddb
        return self.worddb
    
    def dbshow(self):
        for k in self.worddb:
            print("{:16s} {:s}".format(k, self.worddb[k]))

def dbinit(rawfile=rawfile, dbfile=dbfile):
    db = DB(rawfile, dbfile)
    db.dbdump()

def dbload(rawfile=rawfile, dbfile=dbfile):
    db = DB(rawfile, dbfile)
    worddb = db.dbload()
    return worddb

def dbshow(rawfile=rawfile, dbfile=dbfile):
    db = DB(rawfile, dbfile)
    worddb = db.dbload()
    db.dbshow()

if __name__ == "__main__":
    dbinit()
    dbload()
    dbshow()

