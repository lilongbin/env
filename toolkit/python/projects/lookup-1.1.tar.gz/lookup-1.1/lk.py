#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2017-11-16 00:29:08
####################################################

import os
import sys
import lookup
import dbinit

def lk(word=None):
    lookup.lookup(word)

help_info = """Usage:
    lk [--init | --help | -h | word ]
    lk
"""

if __name__ == "__main__":
    word = []
    if len(sys.argv) >= 2:
        if sys.argv[1] == "--init":
            dbinit.dbinit()
            sys.exit(0)
        elif sys.argv[1].lower() in ["--help", "-h"]:
            print(help_info)
            sys.exit(0)
        else:
            word = sys.argv[1:]
    lk(word)

