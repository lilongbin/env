#! /bin/bash
# 2019-01-30 16:37:30

function lk()
{
	local script_abspath=/home/user/toolkit/bin/lk/lk.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

