#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'lookup',
	     version      = '1.1',
	     py_modules   = ['lk', 'lookup', 'dbinit', 'cli'],
	     package_data = {'': ["*.db", "*.json"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'lookup english word',
	    )
