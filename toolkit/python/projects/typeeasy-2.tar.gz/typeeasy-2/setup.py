#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'typeeasy',
	     version      = '2',
	     py_modules   = ['typeeasy', 'cli', 'setcolor'],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'training keyboard skills',
	    )
