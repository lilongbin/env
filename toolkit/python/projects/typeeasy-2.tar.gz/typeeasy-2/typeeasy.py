#! /usr/bin/env python
# coding=utf-8

import os
import sys
import cli
import setcolor
# import setcolor will lead chinese display exception

class TypeEasy(object):
    def __init__(self, filename):
        self.file = filename
        self.cli = cli.CLI()
        self.autoindent = True
        self.error_count = 0
        self.line_count = 0

    def read_line(self):
        try:
            with open(self.file, 'rb') as fd:
                ch = ' '
                chlen = self.cli.char_display_len('\t')
                for line in fd:
                    yield line.replace('\t', ch * chlen)
        except Exception as reason:
            self.cli.printf('ERROR: %s\n' % reason)
            raise reason
    def getch(self):
        return self.cli.getch()
    def printf(self, info):
        self.cli.printf(info)
    def rate(self):
        if self.line_count:
            rate = 100 - float(self.error_count)/self.line_count * 100.0
        else:
            rate = 100.0
        self.printf('The correct rate: %.2f%%\n' % rate)
    def run(self):
        self.error_count = 0
        self.line_count = 0
        for line in self.read_line():
            self.printf('%s' % line)
            self.judge_line(line)
        self.rate()
    def judge_line(self, line):
        line = line.rstrip()
        utmp = ltmp = user_line = ''
        lspace = ' ' * (len(line) - len(line.lstrip()))
        if self.autoindent:
            user_line = lspace
            self.printf(user_line)
        # proc user_line
        while True:
            ch = self.getch()
            if ch == '\r' or ch == '\n':
                utmp = user_line.replace(' ', '')
                ltmp = line.replace(' ', '')
                if not ltmp.strip(): break
                self.printf('\r\n')
                if utmp != ltmp:
                    self.error_count += 1
                self.line_count += 1
                break
            elif ord(ch) == cli.CLI_KEY_BACK or ord(ch) == cli.CLI_KEY_CTRLH:
                rmlen, user_line = self.cli.rm_last_char(user_line)
            elif ord(ch) == cli.CLI_KEY_CTRLW:
                user_line = self.cli.rm_last_word(user_line)
            elif ord(ch) == cli.CLI_KEY_TAB:
                self.printf(' ' * self.cli.char_display_len(ch))
                user_line += ' ' * self.cli.char_display_len(ch)
            elif ord(ch) in [ 3, cli.CLI_KEY_CTRLD, cli.CLI_KEY_QUIT ]:
                self.printf('\r\n Interrupted by keyboard.\r\n')
                sys.exit()
            elif ord(ch) == cli.CLI_KEY_CTRLU:
                user_line = self.cli.rm_one_line(user_line)
            else:
                user_line += ch
                utmp = user_line.replace(' ', '')
                ltmp = line.replace(' ', '')
                if utmp and not (utmp in ltmp and utmp[0]==ltmp[0]):
                    ch = setcolor.setcolor(ch, 'red')
                self.printf(ch)

def main():
    filename = 'test.txt'
    te = TypeEasy(filename)
    te.run()

if __name__ == '__main__':
    main()
