#! /bin/bash

####################################################
# Author      : longbin
# Created date: 2018-01-09 22:24:56
####################################################

libname=${2}
symbol_file=symbol_${2}.txt
NM=nm

if [ -f ${libname} ] ;then
	${NM} -n ${libname} > ${symbol_file}
fi

