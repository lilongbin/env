#! /bin/bash
# 2019-01-30 16:53:40

function pcs()
{
	local script_abspath=/home/user/toolkit/bin/pcs/parser.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

