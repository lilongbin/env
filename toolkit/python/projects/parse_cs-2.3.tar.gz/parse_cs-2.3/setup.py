#! /usr/bin/env python
from distutils.core import setup

setup(
	     name         = 'parse_cs',
	     version      = '2.3',
	     py_modules   = ['parser', 'callstack', 'callstackext'],
	     package_data = {'': ["*.db"],},
	     author       = 'longbin',
	     author_email = 'lilongbin@huawei.com',
	     url          = 'www.huawei.com',
	     description  = 'parse callstack',
	    )
