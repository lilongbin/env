#! /usr/bin/env python
# coding=utf-8
#================================================================
#   Copyright (C) 2017 * Ltd. All rights reserved.
#   
#   File name   : parser.py
#   Author      : longbin
#   Created date: 2017-10-22 23:55:46
#   Description : 
#
#================================================================

import os
import sys
import callstackext

def test():
    cs_file = "callstack.txt"
    sym_file = "symbol.txt"
    mem_map = "mem-map.txt"
    dev = "ar3260"
    cs = callstackext.CallStackExt(cs_file, sym_file, mem_map, dev)
    cs.run()

if __name__ == "__main__":
    test()

