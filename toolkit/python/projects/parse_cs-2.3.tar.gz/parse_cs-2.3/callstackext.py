#! /usr/bin/env python
# coding=utf-8

import os
import callstack
import subprocess

class CallStackExt(callstack.CallStack):
    def __init__(self, cs_file, sym_file, mem_map="", toolchain=""):
        super(CallStackExt, self).__init__(cs_file, sym_file)
        self.mem_map_file = mem_map
        self.toolchain = toolchain
        self.mem_map_dict = {}
        self.cs_sym_ext = {}
        self.cs_sym_final = {}

    def get_mem_map_info(self):
        filename = self.mem_map_file
        if not os.path.isfile(filename):
            return
        mmtmp = {}
        mem_map_dict = self.mem_map_dict
        with open(filename, 'r') as fd:
            for line in fd:
                line = line.strip().split()
                if len(line) != 6 or len(line[0]) not in [17, 25]:
                    continue
                libname = os.path.basename(line[-1])
                if libname not in mmtmp:
                    mmtmp[libname] = line[0].split('-')
                else:
                    for addr in line[0].split('-'):
                        mmtmp[libname].append(addr)
        # get min and maxaddr of every lib
        for libname in mmtmp:
            addrs = [int(addr, 16) for addr in mmtmp[libname]]
            mmtmp[libname][:] = [hex(min(addrs)), hex(max(addrs))]
            # self.showmsg("%20s: %s" % (libname, mmtmp[libname]))
        # filter lib*.so
        for libname in mmtmp:
            if len(libname) >= 3 and '.so' == libname[-3:]:
                mem_map_dict[libname] = mmtmp[libname]
        libname_width = max([len(libname) for libname in mem_map_dict])
        self.showmsg("\r\nmem_map_dict:")
        for libname in mem_map_dict:
            self.showmsg("%*s %s" % (libname_width+1, libname, mem_map_dict[libname]))
        self.mem_map_dict = mem_map_dict
        self.showmsg("")

    def __query_libname_by_csaddr(self, csaddr):
        mem_map = self.mem_map_dict
        for libname in mem_map:
            if int(mem_map[libname][0], 16) <= int(csaddr, 16) <= int(mem_map[libname][1], 16):
                return libname

    def nm_lib2symbol_func(self, libname, toolchain=""):
        shell_script_name = "nm_so.sh"
        if os.path.dirname(__file__):
            shell_script_name = os.path.dirname(__file__) + os.sep + shell_script_name
        # begin nm
        shell_script_cmd = "bash %s %s %s " % (shell_script_name, toolchain, libname)
        sPopen = subprocess.Popen(shell_script_cmd, shell=True, stdout=subprocess.PIPE)
        sPopen.wait()
        self.showmsg("\t$ bash %s %s %s \tReturn: %s" % ("nm_so.sh", toolchain, libname, sPopen.returncode))
        if sPopen.returncode:
            self.showmsg('-'*60)
            self.showmsg("%s" % (sPopen.stdout.read()))
            self.showmsg('-'*60)

    def nm_lib2symbol(self):
        toolchain = self.toolchain
        mem_map = self.mem_map_dict
        callstack = self.callstack
        so_file_list = []
        for csaddr in callstack:
            if csaddr not in self.cs_sym:
                libname = self.__query_libname_by_csaddr(csaddr)
                if libname:
                    so_file_list.append(libname)
        for libname in set(so_file_list):
            self.showmsg("%20s: \t is needed." % libname)
        for libname in set(so_file_list):
            self.showmsg("Start to nm file: %s" % libname)
            if not os.path.isfile(libname):
                self.showmsg("\tERROR: %s: No such file." % libname)
                continue
            self.nm_lib2symbol_func(libname, toolchain)

    def get_relative_addr(self, addr, refaddr):
        if not addr or not refaddr:
            return 0x0
        try:
            int(addr, 16)
            int(refaddr, 16)
        except Exception as reason:
            self.showmsg("ERROR: %s" % reason)
            return 0x0
        if int(addr, 16) >= int(refaddr, 16):
            reladdr = hex(int(addr, 16) - int(refaddr, 16))
        else:
            self.showmsg("Warning: %s should larger than %s" % (addr, refaddr))
            reladdr = 0x0
        return reladdr

    def parse_cs2sym_of_lib(self):
        self.get_mem_map_info()
        self.nm_lib2symbol()
        # self.showmsg("Processing...")
        for csaddr in self.callstack:
            if csaddr in self.cs_sym:
                continue
            libname = self.__query_libname_by_csaddr(csaddr)
            if not libname or not os.path.isfile(libname):
                continue
            headaddr = self.mem_map_dict[libname][0]
            sym_file = "symbol_"+libname+".txt"
            if not os.path.isfile(sym_file):
                self.showmsg("Warning: %s: No such file." % sym_file)
                continue
            reladdr = self.get_relative_addr(csaddr, headaddr)
            self.showmsg("get relative addr: %s %s -> %s" %
                            (headaddr, csaddr, reladdr))
            res = self.cs_match_sym(reladdr, sym_file)
            if res and len(res) == 3:
                self.cs_sym_ext[csaddr] = [libname, res[-1]]
                continue

    def merge_cs_sym(self):
        self.cs_sym_final = {}
        for csaddr in self.callstack:
            if csaddr in self.cs_sym:
                self.cs_sym_final[csaddr] = self.cs_sym[csaddr]
                continue
            if csaddr in self.cs_sym_ext:
                self.cs_sym_final[csaddr] = self.cs_sym_ext[csaddr]
                continue

    def run(self):
        super(CallStackExt, self).run()
        self.parse_cs2sym_of_lib()
        self.merge_cs_sym()
        self.show_cs_sym(self.cs_sym_final)
        
def test():
    cs_file = 'callstack.txt'
    sym_file = 'symbol_ar3260.txt'
    mem_map = 'mem-map.txt'
    dev = 'ar3260'
    cs = CallStackExt(cs_file, sym_file, mem_map, dev)
    cs.run()
    
if __name__ == "__main__":
    test()

