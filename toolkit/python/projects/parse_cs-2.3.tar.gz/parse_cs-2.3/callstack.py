#! /usr/bin/env python
# coding=utf-8
#================================================================
#   Copyright (C) 2017 * Ltd. All rights reserved.
#   
#   File name   : parse_callstack.py
#   Author      : longbin
#   Created date: 2017-10-22 23:55:46
#   Description : 
#
#================================================================

import os
import sys
import re

class CallStack(object):
    def __init__(self, cs_file, sym_file):
        self.sys_version = sys.version_info[0]
        self.__print_func="print(info)," if self.sys_version == 2 else "print(info, end='')"
        self.cs_file = cs_file
        self.sym_file = [sym_file, ]
        self.callstack = []
        self.cs_sym = {}
        self.__update_callstack()

    def showmsg(self, *msg, **kwarg):
        for info in msg:
            eval(self.__print_func)
        print("")

    def __update_callstack(self):
        self.showmsg("callstack file: %s" % self.cs_file)
        if not os.path.isfile(self.cs_file):
            return None
        HexAddr = re.compile("0x[0-9a-f]{6,12}")
        with open(self.cs_file, 'r') as fd:
            for line in fd:
                line = line.lower()
                addrs = HexAddr.findall(line)
                for addr in addrs:
                    try:
                        int(addr, 16)
                    except Exception as reason:
                        self.showmsg("ERROR: %s: Invalid hex addr." % addr)
                        continue
                    if self.callstack and int(self.callstack[-1], 16) == int(addr, 16):
                        continue
                    addr = str("0x%08x" % int(addr, 16))
                    self.callstack.append(addr)
        # self.showmsg(self.callstack)

    def add_symbol_file(self, sym_file):
        if not sym_file:
            return
        if not os.path.isfile(sym_file):
            return
        if sym_file not in self.sym_file:
            self.sym_file.append(sym_file)

    def cs_match_sym(self, csaddr, sym_file):
        # self.showmsg("Matching: ", sym_file, csaddr)
        if not sym_file or not os.path.isfile(sym_file):
            return
        if not csaddr:
            return
        with open(sym_file, 'r') as fd:
            last_line = ['0xffffffff', '', '']
            match_line = None
            for line in fd:
                line = line.strip().split()
                if len(line) != 3:
                    continue
                if int(line[0], 16) <= int(csaddr, 16):
                    last_line = line
                    # self.showmsg(line)
                    continue
                if int(csaddr, 16) < int(line[0], 16):
                    if int(last_line[0], 16) <= int(csaddr, 16):
                        # self.showmsg("match: ", last_line)
                        match_line = last_line
                    break
        return match_line

    def show_cs_sym(self, cs_sym=''):
        if not cs_sym:
            cs_sym = self.cs_sym
        line_format = "%-*s  %*s  %-*s"
        callstack = self.callstack
        sym_file = self.sym_file
        first, second, third = [0, 0, 0]
        if callstack:
            first = max([len(csaddr) for csaddr in callstack])
        else:
            self.showmsg("No valid hex addr found in callstack file.")
            return
        # self.showmsg("show: ", self.cs_sym)
        for csaddr in cs_sym:
            if len(cs_sym[csaddr]) != 2:
                continue
            if len(csaddr) > first:
                first = len(csaddr)
            if len(cs_sym[csaddr][0]) > second:
                second = len(cs_sym[csaddr][0])
            if len(cs_sym[csaddr][1]) > third:
                third = len(cs_sym[csaddr][1])
        # self.showmsg(first, second, third)
        self.showmsg("\r\nThe final parsed callstack result:")
        self.showmsg("*"*(len(line_format) + first + second + third))
        for csaddr in callstack:
            if csaddr in cs_sym and len(cs_sym[csaddr]) == 2:
                self.showmsg(line_format % (first, csaddr, second, cs_sym[csaddr][0], third, cs_sym[csaddr][1]))
            else:
                self.showmsg(line_format % (first, csaddr, second, "", third, "__unknown"))
        self.showmsg("*"*(len(line_format) + first + second + third))

    def run(self):
        self.showmsg("symbol file: %s" % self.sym_file)
        self.showmsg("Processing... Please wait...")
        # self.showmsg(self.callstack)
        for sym_file in self.sym_file:
            if not os.path.isfile(sym_file):
                self.showmsg("ERROR: %s: No such file." % sym_file)
        for csaddr in self.callstack:
            if csaddr in self.cs_sym:
                continue
            for sym_file in self.sym_file:
                res = self.cs_match_sym(csaddr, sym_file)
                if res and len(res) == 3:
                    self.cs_sym[csaddr] = [sym_file, res[2]]
            # self.showmsg(self.cs_sym)
        self.show_cs_sym()

def test():
    cs_file = "callstack.txt"
    sym_file = "symbol.txt"
    cs = CallStack(cs_file, sym_file)
    cs.run()

if __name__ == "__main__":
    test()

