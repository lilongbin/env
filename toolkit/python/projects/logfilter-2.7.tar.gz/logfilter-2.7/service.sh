#! /bin/bash
# 2020-04-08 12:08:44

function logfilter()
{
	local script_abspath=/home/user/.toolkit/bin/logfilter-2.3/logfilter.py
	if [ "${script_abspath}" = "" ] ;then
		return
	fi
	if [ -f ${script_abspath} ] ;then
		python ${script_abspath} $*
	fi
}

