#! /usr/bin/env python
# coding=utf-8
####################################################
# Author      : longbin
# Created date: 2019-09-22 21:03:58
####################################################

import os
import sys
import re
import time

import config

g_dbglog = False
g_digitletters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
g_add_raw_txt = False

def usage():
    helpinfo = """
Usage:
    logaa -h                    #get help info
    logaa [-r rule] <logfile>   #process logfile with rule
    logaa [-n|-d|-a|-L] rule    #create/delete/append/load rule
    logaa --list                #list all rules in configure directory
    """
    print("%s" % helpinfo)

class FilterRule(object):
    def __init__(self, logfile, rulefile, rules):
        self.raw_file = logfile
        self.rulefile = rulefile
        self.out_file = self.raw_file + "-" + self.rulefile + ".html"
        self.filterRules = self.init_rule(rules)
    
    def init_rule(self, rules):
        if g_dbglog: print(rules)
        for idx,frule in enumerate(rules):
            if g_dbglog: print(frule)
            # doSearch
            doSearch = frule.get("doSearch")
            if doSearch == "false":
                doSearch = False
            else:
                doSearch = True
            rules[idx]["doSearch"] = doSearch

            keyword = frule.get("keyword")
            stylename = "st_"
            for chr in keyword:
                if chr in g_digitletters:
                    stylename += chr
            rules[idx]["stylename"] = stylename
            # print("keyword=%s" % keyword)

            ftype = frule.get("type")
            if "re" == ftype:
                # compile
                re_kw = re.compile("(%s)" % keyword, re.I)
                rules[idx]["re_keyword"] = re_kw
            else:
                ftype = "normal"
                rules[idx]["type"] = ftype

            bgcolor = frule.get("bg")
            if bgcolor:
                bgcolor = "background-color:%s" % bgcolor
            else:
                bgcolor = ""
            rules[idx]["bgcolor"] = bgcolor

            # fgcolor = frule.get("fg")
            fgcolor = frule.get("fg")
            if fgcolor:
                fgcolor = "color:%s" % fgcolor
            else:
                fgcolor = ""
            rules[idx]["fgcolor"] = fgcolor

            # matchCase
            matchCase = frule.get("matchCase")
            if matchCase == "true":
                matchCase = True
            else:
                matchCase = False
            rules[idx]["matchCase"] = matchCase

            # hide
            hide = frule.get("hide")
            if hide == "true":
                hide = True
                rules[idx]["fgcolor"] = "color:white"
                rules[idx]["bgcolor"] = "backgroud-color:white"
            else:
                hide = False
            rules[idx]["hide"] = hide

            # bold
            bold = frule.get("bold")
            if bold == "true":
                bold = "font-weight:bold"
            else:
                bold = ""
            rules[idx]["bold"] = bold

        rules.reverse()
        if g_dbglog: print(rules)
        return rules
    
    def filter_proc(self, linenm, line=""):
        if not line.strip():
            return False
        matchwords =  None
        for frule in self.filterRules:
            if False == frule.get("doSearch"):
                continue
            # if g_dbglog: print(frule)
            if "re" != frule.get("type"):
                # normal
                keyword = frule.get("keyword")
                if -1 != line.find(keyword):
                    matchwords = ["%s" % keyword,]
            else:
                # re
                re_kw = frule.get("re_keyword")
                matchwords = re_kw.findall(line)
            if matchwords:
                stylename = frule.get("stylename")
                select = frule.get("select")
                if "line" == select:
                    line = "<span class=\"%s\">%s</span>" % (stylename, line)
                else: #"word" == select:
                    # print(matchwords[0])
                    word = matchwords[0]
                    # for word in matchwords[0]:
                    if word:
                        repl = "<span class=\"%s\">%s</span>" % (stylename, word)
                        line = line.replace(word, repl)
                #line = "line %5d: %s<br>" % (linenm, line)
                line = "line %5d: %s" % (linenm, line)
                if g_dbglog: print(line)
                return line
        else:
            return False
    
    def add_html_header(self):
        header="""<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>"""
        with open(self.out_file, "w") as wfd:
            if g_dbglog: print("add header: \n%s" % header)
            wfd.write(header + os.linesep)
        self.add_html_style()

        header_tail="""<title>%s</title>
</head>

<body>
""" % (self.out_file)
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add header_tail: \n%s" % header_tail)
            wfd.write(header_tail + os.linesep)
    
    def add_html_style(self):
        mystyles = """
    pre {
        white-space: pre-wrap;
        white-space: -moz-pre-wrap;
        white-space: -pre-wrap;
        white-space: -o-pre-wrap;
        *word-wrap: break-word;
        *white-space : normal ;
    }
    .glb {font-size:13px;}"""
        for frule in self.filterRules:
            style = ""
            stylename = frule.get("stylename")
            bgcolor = frule.get("bgcolor")
            fgcolor = frule.get("fgcolor")
            bold = frule.get("bold")
            style += bgcolor
            if bgcolor:
                style += ";"
            style += fgcolor
            if fgcolor:
                style += ";"
            style += bold
            if bold:
                style += ";"
            mystyles += "\n    .%s { %s }" % (stylename, style)
        html_style = """<style type="text/css">%s\n</style>""" % mystyles
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add style: \n%s" % html_style)
            wfd.write(html_style + os.linesep)

    def add_html_rawtxt(self):
        rfd = open(self.raw_file)
        wfd = open(self.out_file, "a+")
        header = """
<style class="text/css">
.logFilterRawContentStyle {
	font-size:13px;
	OVERFLOW-Y:auto;
	height:300px;
	background-color:#FEFEFE;
}
</style>

<!--h1>log.log</h1-->
<div style="background-color:#DDDDDD;">%s:</div>
<div id="logFilterRawContent" class="logFilterRawContentStyle">
<pre>
""" % (self.raw_file)
        wfd.write(header)
        linenm = 0
        for line in rfd:
            linenm += 1
            # print(line)
            result = "%5d: %s" % (linenm, line)
            if result:
                #wfd.write(result + os.linesep)
                wfd.write(result)
        if g_dbglog: print("add raw txt complete.")
        tail = """</pre>
</div>
"""
        wfd.write(tail)
        rfd.close()
        wfd.close()

    def add_html_body(self):
        ResultContentStyle = """<style class="text/css">
.logFilterResultContentStyle {
	font-size:13px;
	OVERFLOW-Y:auto;
	height:350px;
	background-color:#FEFEFE;
}
</style>
"""
        mystyle = """<style class="text/css">
.logFilterResultContentStyle {
	font-size:13px;
}
</style>
"""

        if g_add_raw_txt:
            self.add_html_rawtxt()
            style = ResultContentStyle
        else:
            style = mystyle
        rfd = open(self.raw_file)
        wfd = open(self.out_file, "a+")
        wfd.write(style)
        header = """
<div style="background-color:#DDDDDD;">%s filtered:</div>
<div id="logFilterResultContent" class="logFilterResultContentStyle">
<pre>
""" % (self.raw_file)
        wfd.write(header)
        linenm = 0
        for line in rfd:
            linenm += 1
            # print(line)
            if not line.strip():
                continue
            result = self.filter_proc(linenm, line)
            if result:
                #wfd.write(result + os.linesep)
                wfd.write(result)
        if g_dbglog: print("add body complete.")
        tail = """</pre>
</div>"""
        wfd.write(tail)
        rfd.close()
        wfd.close()
    
    def add_html_footer(self):
        timenow = time.asctime(time.localtime(time.time()))
        footer = """
<div>generated on %s (%s)<div>
</body>
</html>""" % (timenow, os.getenv("USER"))
        with open(self.out_file, "a+") as wfd:
            if g_dbglog: print("add footer: \n%s" % footer)
            wfd.write(footer + os.linesep)
    
    def run(self):
        self.add_html_header()
        self.add_html_body()
        self.add_html_footer()
        print("result restore to file: %s" % self.out_file)

def proc(logfile, rulefile, Rules):
    if not logfile.strip():
        print("Error: invalid parameter.")
        return
    if not os.path.isfile(logfile):
        print("Error: %s: No such file." % logfile)
        return
    print("process logfile(%s) with rule(%s)" % (logfile, rulefile))
    fr = FilterRule(logfile, rulefile, Rules)
    fr.run()

if __name__ == "__main__":
    cfg = config.RuleConfigure()
    logfile = ""
    rulefile = ""
    if g_dbglog: print("main: %s" % sys.argv)
    if len(sys.argv) < 2:
        usage()
        sys.exit(0)
    if sys.argv[1].lower() in ["-h", "--help", "?"]:
        usage()
        sys.exit(0)
    if sys.argv[1].lower() in ["--list"]:
        if len(sys.argv) == 2:
            #show rules
            cfg.list()
            sys.exit()
    if sys.argv[1].lower() in ["-r"]:
        # load rule
        if len(sys.argv) != 4:
            usage()
            sys.exit()
        rulefile = sys.argv[2]
        logfile = sys.argv[-1]
        if g_dbglog: print("use rule: %s for %s" % (rulefile, filename))
        cfg.load(rulefile)
    if sys.argv[1].lower() in ["-n", "-d", "-a", "-L"]:
        # manage rule
        if len(sys.argv) != 3:
            usage()
            sys.exit()
        option = sys.argv[1].lower()
        rulefile = sys.argv[-1]
        if g_dbglog: print("manage rule: %s %s" % (rulefile, option))
        if option == "-L":
            cfg.load(rulefile)
        elif option == "-d":
            cfg.remove(rulefile)
        elif option == "-n" or option == "-a":
            cfg.create(rulefile)
        else:
            cfg.load(rulefile)
        sys.exit()
    rulefile = cfg.getRuleFileBasename()
    Rules = cfg.getRules()
    logfile = sys.argv[-1]
    proc(logfile, rulefile, Rules)

