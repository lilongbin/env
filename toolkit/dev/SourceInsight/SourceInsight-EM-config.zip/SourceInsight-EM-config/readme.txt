
将Base文件夹中的文件拷贝到以下目录
%USERPROFILE%\Documents\Source Insight\Projects\Base
4.0放以下目录
%USERPROFILE%\Documents\Source Insight 4.0\Projects\Base

将settings目录下的文件拷贝到以下目录
%USERPROFILE%\Documents\Source Insight\Settings
4.0放以下目录
%USERPROFILE%\Documents\Source Insight 4.0\Settings

创建Base工程并加载Base目录的文件并关闭Base工程
然后创建其他工程即可使用


一些注意事项
1. 3.5版本默认的编码方式为系统默认的编码方式，即 Windows ANSI，4.0版本的默认编码方式则为 UTF-8;
	这就导致了在 3.5 版本中可以正常显示的中文注释，在 4.0 版本中变成乱码。修改方式如下：
	在 Options->Preferences->Files 中的最下面，Default enconding 从 UTF-8 修改为 ANSI.
2. 自动补全功能默认不使用 Tab 键补全，只能使用回车键，在 Options->Typing 中间那栏 Auto Completion 中，勾选 Tab key selects item 即可.
3. 代码缩进时SI 有一个智能缩进，会将大括号自动缩进在下面后两格。可在 Options->Preference->SyntaxFormating->File Types
	或者直接按Alt+t 右边一栏 Auto Indent 中修改，从 Smart 改为 Simple 即可。

